def translate():
    thisdict={"merry":"god",
              "christmas":"jul",
              "and":"och",
              "happy":"gott",
              "new":"nytt",
              "year":"ar"}
    for x in thisdict:
      print(x ,end=" ")
    print("\n")

    for x in thisdict.values():
      print(x ,end=" ")
translate()

