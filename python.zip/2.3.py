x=[]
y=[]
n=int(input("enter size of list:"))
for i in range(0,n):
    elements=str(input())
    x.append(elements)
    a=len(elements)
    y.append(a)
print(y)
