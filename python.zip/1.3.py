
x= 5
a= int(input("Enter the number:"))
while x!=a:
     a= int(input("Enter the number:"))
print("Correct!")     

