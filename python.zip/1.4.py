first_name= str(input("Enter the first name:"))
last_name= str(input("Enter the last name:"))
whole_name=first_name+'.'+last_name
print(whole_name)

