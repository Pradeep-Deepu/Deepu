def generate_n_char():
    n= int(input("enter size:"))
    c=str(input("enter your string:"))
    for i in range(n):
        print(c,end='')
generate_n_char()
