string1= str(input("Enter your string:"))
string2= string1.swapcase()
print("Your toggled string is:",  string2)
