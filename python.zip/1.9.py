x=[]
n=int(input("enter size fo the list:"))
for i in range(0,n):
    elements=int(input())
    x.append(elements)
for num in x:
   y= "*"*num
   print(y)
