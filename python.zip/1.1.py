name='vasu'
print("Hello",name)
