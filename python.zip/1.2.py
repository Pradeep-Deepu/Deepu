a= int(input("Enter first number:"))
b= int(input("Enter second number:"))
sum= a+b
if sum>0:
    print("sum is positive")
elif (sum==0):
    print("sum is zero")
else:
    print("sum is negative")


